import { db } from "@/db";
import { authors, categories, comments, posts } from "@/db/schema";
import { and, desc, eq, ilike, inArray, ne, or, sql } from "drizzle-orm";

export type PostWithRelations = Awaited<ReturnType<typeof getAllPosts>>[number];

function basePostSelect() {
  return {
    id: posts.id,
    title: posts.title,
    slug: posts.slug,
    excerpt: posts.excerpt,
    content: posts.content,
    coverImage: posts.coverImage,
    tags: posts.tags,
    readTimeMinutes: posts.readTimeMinutes,
    featured: posts.featured,
    viewCount: posts.viewCount,
    publishedAt: posts.publishedAt,
    category: {
      id: categories.id,
      name: categories.name,
      slug: categories.slug,
      icon: categories.icon,
    },
    author: {
      id: authors.id,
      name: authors.name,
      slug: authors.slug,
      role: authors.role,
      avatarUrl: authors.avatarUrl,
    },
  } as const;
}

export async function getAllPosts() {
  return db
    .select(basePostSelect())
    .from(posts)
    .innerJoin(categories, eq(posts.categoryId, categories.id))
    .innerJoin(authors, eq(posts.authorId, authors.id))
    .orderBy(desc(posts.publishedAt));
}

export async function getFeaturedPosts(limit = 3) {
  return db
    .select(basePostSelect())
    .from(posts)
    .innerJoin(categories, eq(posts.categoryId, categories.id))
    .innerJoin(authors, eq(posts.authorId, authors.id))
    .where(eq(posts.featured, true))
    .orderBy(desc(posts.publishedAt))
    .limit(limit);
}

export async function getPopularPosts(limit = 5) {
  return db
    .select(basePostSelect())
    .from(posts)
    .innerJoin(categories, eq(posts.categoryId, categories.id))
    .innerJoin(authors, eq(posts.authorId, authors.id))
    .orderBy(desc(posts.viewCount))
    .limit(limit);
}

export async function getPostBySlug(slug: string) {
  const rows = await db
    .select(basePostSelect())
    .from(posts)
    .innerJoin(categories, eq(posts.categoryId, categories.id))
    .innerJoin(authors, eq(posts.authorId, authors.id))
    .where(eq(posts.slug, slug))
    .limit(1);

  return rows[0] ?? null;
}

export async function incrementPostViews(postId: number) {
  await db
    .update(posts)
    .set({ viewCount: sql`${posts.viewCount} + 1` })
    .where(eq(posts.id, postId));
}

export async function getRelatedPosts(postId: number, categoryId: number, limit = 3) {
  return db
    .select(basePostSelect())
    .from(posts)
    .innerJoin(categories, eq(posts.categoryId, categories.id))
    .innerJoin(authors, eq(posts.authorId, authors.id))
    .where(and(eq(posts.categoryId, categoryId), ne(posts.id, postId)))
    .orderBy(desc(posts.publishedAt))
    .limit(limit);
}

export async function getPostsByCategorySlug(slug: string) {
  return db
    .select(basePostSelect())
    .from(posts)
    .innerJoin(categories, eq(posts.categoryId, categories.id))
    .innerJoin(authors, eq(posts.authorId, authors.id))
    .where(eq(categories.slug, slug))
    .orderBy(desc(posts.publishedAt));
}

export async function getPostsByAuthorSlug(slug: string) {
  return db
    .select(basePostSelect())
    .from(posts)
    .innerJoin(categories, eq(posts.categoryId, categories.id))
    .innerJoin(authors, eq(posts.authorId, authors.id))
    .where(eq(authors.slug, slug))
    .orderBy(desc(posts.publishedAt));
}

export async function getPostsByTag(tag: string) {
  return db
    .select(basePostSelect())
    .from(posts)
    .innerJoin(categories, eq(posts.categoryId, categories.id))
    .innerJoin(authors, eq(posts.authorId, authors.id))
    .where(sql`${tag} = ANY(${posts.tags})`)
    .orderBy(desc(posts.publishedAt));
}

export async function searchPosts(query: string) {
  const like = `%${query}%`;
  return db
    .select(basePostSelect())
    .from(posts)
    .innerJoin(categories, eq(posts.categoryId, categories.id))
    .innerJoin(authors, eq(posts.authorId, authors.id))
    .where(
      or(
        ilike(posts.title, like),
        ilike(posts.excerpt, like),
        ilike(posts.content, like),
      ),
    )
    .orderBy(desc(posts.publishedAt));
}

export async function getAllCategories() {
  return db.select().from(categories).orderBy(categories.name);
}

export async function getCategoryBySlug(slug: string) {
  const rows = await db.select().from(categories).where(eq(categories.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function getAllAuthors() {
  return db.select().from(authors).orderBy(authors.name);
}

export async function getAuthorBySlug(slug: string) {
  const rows = await db.select().from(authors).where(eq(authors.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function getAllTags() {
  const rows = await db.select({ tags: posts.tags }).from(posts);
  const set = new Set<string>();
  for (const row of rows) {
    for (const tag of row.tags) set.add(tag);
  }
  return Array.from(set).sort();
}

export async function getCommentsForPost(postId: number) {
  return db
    .select()
    .from(comments)
    .where(eq(comments.postId, postId))
    .orderBy(desc(comments.createdAt));
}

export async function getPostsByIds(ids: number[]) {
  if (ids.length === 0) return [];
  return db
    .select(basePostSelect())
    .from(posts)
    .innerJoin(categories, eq(posts.categoryId, categories.id))
    .innerJoin(authors, eq(posts.authorId, authors.id))
    .where(inArray(posts.id, ids));
}
