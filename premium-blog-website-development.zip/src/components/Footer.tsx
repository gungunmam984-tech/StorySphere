import Link from "next/link";
import { getAllCategories } from "@/lib/queries";
import NewsletterForm from "./NewsletterForm";

export default async function Footer() {
  const categories = await getAllCategories();

  return (
    <footer className="border-t border-amber-100 bg-stone-950 text-stone-300">
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <Link href="/" className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-amber-500 to-rose-500 text-base font-semibold text-white">
                L
              </span>
              <span className="font-serif text-xl font-semibold text-white">Lumière.</span>
            </Link>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-stone-400">
              A premium journal on technology, travel, lifestyle, finance and wellbeing —
              written to help you live and work with more intention.
            </p>
            <div className="mt-5 flex gap-3">
              {["Twitter", "Instagram", "LinkedIn"].map((label) => (
                <span
                  key={label}
                  className="grid h-9 w-9 place-items-center rounded-full border border-stone-800 text-xs text-stone-400"
                  title={label}
                >
                  {label[0]}
                </span>
              ))}
            </div>
          </div>

          <div>
            <p className="text-sm font-semibold uppercase tracking-wider text-stone-100">Explore</p>
            <ul className="mt-4 space-y-3 text-sm text-stone-400">
              <li><Link href="/blog" className="hover:text-amber-400">All Articles</Link></li>
              <li><Link href="/about" className="hover:text-amber-400">About Us</Link></li>
              <li><Link href="/contact" className="hover:text-amber-400">Contact</Link></li>
              <li><Link href="/search" className="hover:text-amber-400">Search</Link></li>
            </ul>
          </div>

          <div>
            <p className="text-sm font-semibold uppercase tracking-wider text-stone-100">Categories</p>
            <ul className="mt-4 space-y-3 text-sm text-stone-400">
              {categories.map((category) => (
                <li key={category.id}>
                  <Link href={`/category/${category.slug}`} className="hover:text-amber-400">
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-sm font-semibold uppercase tracking-wider text-stone-100">
              Join the newsletter
            </p>
            <p className="mt-4 text-sm text-stone-400">
              One thoughtful email a week. No spam, unsubscribe any time.
            </p>
            <div className="mt-4">
              <NewsletterForm variant="dark" />
            </div>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-stone-800 pt-8 text-xs text-stone-500 sm:flex-row">
          <p>© {new Date().getFullYear()} Lumière Journal. All rights reserved.</p>
          <div className="flex gap-6">
            <Link href="/privacy" className="hover:text-amber-400">Privacy Policy</Link>
            <Link href="/terms" className="hover:text-amber-400">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
