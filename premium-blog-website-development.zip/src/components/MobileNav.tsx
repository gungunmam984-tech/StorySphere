"use client";

import Link from "next/link";
import { useState } from "react";

type Category = {
  id: number;
  name: string;
  slug: string;
  icon: string;
};

export default function MobileNav({ categories }: { categories: Category[] }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="lg:hidden">
      <button
        aria-label="Toggle menu"
        onClick={() => setOpen((v) => !v)}
        className="grid h-10 w-10 place-items-center rounded-full border border-stone-200 text-stone-700"
      >
        {open ? (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        ) : (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        )}
      </button>

      {open && (
        <div className="absolute left-0 right-0 top-full border-b border-amber-100 bg-[#fdfaf4] px-6 py-6 shadow-lg">
          <nav className="flex flex-col gap-4 text-sm font-medium text-stone-700">
            <Link href="/" onClick={() => setOpen(false)}>
              Home
            </Link>
            <Link href="/blog" onClick={() => setOpen(false)}>
              All Articles
            </Link>
            <div className="border-t border-stone-200 pt-3">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-stone-400">
                Categories
              </p>
              <div className="flex flex-col gap-2">
                {categories.map((category) => (
                  <Link
                    key={category.id}
                    href={`/category/${category.slug}`}
                    onClick={() => setOpen(false)}
                    className="flex items-center gap-2"
                  >
                    <span>{category.icon}</span>
                    {category.name}
                  </Link>
                ))}
              </div>
            </div>
            <Link href="/about" onClick={() => setOpen(false)} className="border-t border-stone-200 pt-3">
              About
            </Link>
            <Link href="/contact" onClick={() => setOpen(false)}>
              Contact
            </Link>
            <Link href="/search" onClick={() => setOpen(false)}>
              Search
            </Link>
          </nav>
        </div>
      )}
    </div>
  );
}
