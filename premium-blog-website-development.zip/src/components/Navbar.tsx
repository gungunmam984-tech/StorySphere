import Link from "next/link";
import { getAllCategories } from "@/lib/queries";
import MobileNav from "./MobileNav";

export default async function Navbar() {
  const categories = await getAllCategories();

  return (
    <header className="sticky top-0 z-50 border-b border-amber-100/70 bg-[#fdfaf4]/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-6 px-6 py-4">
        <Link href="/" className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-amber-500 to-rose-500 text-base font-semibold text-white shadow-sm">
            L
          </span>
          <span className="font-serif text-xl font-semibold tracking-tight text-stone-900">
            Lumière<span className="text-amber-600">.</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-7 text-sm font-medium text-stone-700 lg:flex">
          <Link href="/" className="transition hover:text-amber-700">
            Home
          </Link>
          <Link href="/blog" className="transition hover:text-amber-700">
            All Articles
          </Link>
          <div className="group relative">
            <button className="flex items-center gap-1 transition hover:text-amber-700">
              Categories
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className="mt-px">
                <path d="M2 4l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
            <div className="invisible absolute left-1/2 top-full z-20 w-56 -translate-x-1/2 pt-3 opacity-0 transition group-hover:visible group-hover:opacity-100">
              <div className="overflow-hidden rounded-2xl border border-amber-100 bg-white shadow-xl">
                {categories.map((category) => (
                  <Link
                    key={category.id}
                    href={`/category/${category.slug}`}
                    className="flex items-center gap-2 px-4 py-3 text-sm text-stone-700 transition hover:bg-amber-50 hover:text-amber-800"
                  >
                    <span>{category.icon}</span>
                    {category.name}
                  </Link>
                ))}
              </div>
            </div>
          </div>
          <Link href="/about" className="transition hover:text-amber-700">
            About
          </Link>
          <Link href="/contact" className="transition hover:text-amber-700">
            Contact
          </Link>
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <Link
            href="/search"
            aria-label="Search"
            className="grid h-10 w-10 place-items-center rounded-full border border-stone-200 text-stone-600 transition hover:border-amber-300 hover:text-amber-700"
          >
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
              <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
              <path d="M21 21l-4.3-4.3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </Link>
          <Link
            href="/blog"
            className="rounded-full bg-stone-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-amber-700"
          >
            Start Reading
          </Link>
        </div>

        <MobileNav categories={categories} />
      </div>
    </header>
  );
}
