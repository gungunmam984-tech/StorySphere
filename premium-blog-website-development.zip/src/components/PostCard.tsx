import Image from "next/image";
import Link from "next/link";
import { formatDate, formatNumber } from "@/lib/format";
import type { PostWithRelations } from "@/lib/queries";

export default function PostCard({
  post,
  variant = "default",
}: {
  post: PostWithRelations;
  variant?: "default" | "horizontal" | "compact";
}) {
  if (variant === "compact") {
    return (
      <Link href={`/blog/${post.slug}`} className="group flex items-center gap-4">
        <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl">
          <Image src={post.coverImage} alt={post.title} fill className="object-cover transition duration-300 group-hover:scale-110" />
        </div>
        <div>
          <p className="line-clamp-2 text-sm font-semibold text-stone-800 transition group-hover:text-amber-700">
            {post.title}
          </p>
          <p className="mt-1 text-xs text-stone-500">{formatDate(post.publishedAt)}</p>
        </div>
      </Link>
    );
  }

  if (variant === "horizontal") {
    return (
      <Link
        href={`/blog/${post.slug}`}
        className="group flex flex-col gap-5 overflow-hidden rounded-2xl border border-stone-100 bg-white p-3 transition hover:shadow-lg sm:flex-row"
      >
        <div className="relative h-52 shrink-0 overflow-hidden rounded-xl sm:h-auto sm:w-72">
          <Image src={post.coverImage} alt={post.title} fill className="object-cover transition duration-500 group-hover:scale-105" />
        </div>
        <div className="flex flex-col justify-center px-2 py-2">
          <span className="w-fit rounded-full bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-700">
            {post.category.icon} {post.category.name}
          </span>
          <h3 className="mt-3 font-serif text-xl font-semibold leading-snug text-stone-900 transition group-hover:text-amber-700 sm:text-2xl">
            {post.title}
          </h3>
          <p className="mt-2 line-clamp-2 text-sm text-stone-600">{post.excerpt}</p>
          <div className="mt-4 flex items-center gap-3 text-xs text-stone-500">
            <span>{post.author.name}</span>
            <span>·</span>
            <span>{formatDate(post.publishedAt)}</span>
            <span>·</span>
            <span>{post.readTimeMinutes} min read</span>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link
      href={`/blog/${post.slug}`}
      className="group flex flex-col overflow-hidden rounded-2xl border border-stone-100 bg-white transition hover:-translate-y-1 hover:shadow-xl"
    >
      <div className="relative h-52 w-full overflow-hidden">
        <Image src={post.coverImage} alt={post.title} fill className="object-cover transition duration-500 group-hover:scale-105" />
        <span className="absolute left-3 top-3 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-stone-800 backdrop-blur">
          {post.category.icon} {post.category.name}
        </span>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-serif text-lg font-semibold leading-snug text-stone-900 transition group-hover:text-amber-700">
          {post.title}
        </h3>
        <p className="mt-2 line-clamp-2 flex-1 text-sm text-stone-600">{post.excerpt}</p>
        <div className="mt-4 flex items-center justify-between border-t border-stone-100 pt-3 text-xs text-stone-500">
          <span>{post.author.name}</span>
          <span className="flex items-center gap-3">
            <span>{post.readTimeMinutes} min</span>
            <span>👁 {formatNumber(post.viewCount)}</span>
          </span>
        </div>
      </div>
    </Link>
  );
}
