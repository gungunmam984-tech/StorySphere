"use client";

import { FormEvent, useState } from "react";

export default function NewsletterForm({ variant = "light" }: { variant?: "light" | "dark" }) {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  const isDark = variant === "dark";

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Something went wrong");
      setStatus("success");
      setMessage("You're subscribed! Check your inbox soon.");
      setEmail("");
    } catch (err) {
      setStatus("error");
      setMessage(err instanceof Error ? err.message : "Something went wrong");
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-2">
      <div className="flex overflow-hidden rounded-full border transition focus-within:ring-2 focus-within:ring-amber-400"
        style={{ borderColor: isDark ? "#3f3a33" : "#e7dcc8" }}
      >
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className={`w-full bg-transparent px-4 py-2.5 text-sm outline-none ${
            isDark ? "text-white placeholder:text-stone-500" : "text-stone-900 placeholder:text-stone-400"
          }`}
        />
        <button
          type="submit"
          disabled={status === "loading"}
          className="whitespace-nowrap bg-amber-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-amber-700 disabled:opacity-60"
        >
          {status === "loading" ? "..." : "Subscribe"}
        </button>
      </div>
      {message && (
        <p className={`text-xs ${status === "error" ? "text-rose-400" : "text-emerald-500"}`}>{message}</p>
      )}
    </form>
  );
}
