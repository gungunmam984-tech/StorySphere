import { Fragment } from "react";

function renderInline(text: string, keyPrefix: string) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g).filter(Boolean);
  return parts.map((part, idx) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return <strong key={`${keyPrefix}-${idx}`}>{part.slice(2, -2)}</strong>;
    }
    return <Fragment key={`${keyPrefix}-${idx}`}>{part}</Fragment>;
  });
}

export default function PostContent({ content }: { content: string }) {
  const blocks = content.split(/\n\n+/);
  const elements: React.ReactNode[] = [];
  let listBuffer: { type: "ul" | "ol"; items: string[] } | null = null;

  const flushList = (key: string) => {
    if (!listBuffer) return;
    const ListTag = listBuffer.type;
    elements.push(
      <ListTag key={key}>
        {listBuffer.items.map((item, idx) => (
          <li key={idx}>{renderInline(item, `${key}-li-${idx}`)}</li>
        ))}
      </ListTag>,
    );
    listBuffer = null;
  };

  blocks.forEach((block, blockIdx) => {
    const lines = block.split("\n").map((l) => l.trim()).filter(Boolean);

    lines.forEach((line, lineIdx) => {
      const key = `b${blockIdx}-l${lineIdx}`;

      if (line.startsWith("## ")) {
        flushList(`flush-${key}`);
        elements.push(<h2 key={key}>{renderInline(line.slice(3), key)}</h2>);
        return;
      }

      if (/^[-*]\s+/.test(line)) {
        if (!listBuffer || listBuffer.type !== "ul") {
          flushList(`flush-${key}`);
          listBuffer = { type: "ul", items: [] };
        }
        listBuffer.items.push(line.replace(/^[-*]\s+/, ""));
        return;
      }

      if (/^\d+\.\s+/.test(line)) {
        if (!listBuffer || listBuffer.type !== "ol") {
          flushList(`flush-${key}`);
          listBuffer = { type: "ol", items: [] };
        }
        listBuffer.items.push(line.replace(/^\d+\.\s+/, ""));
        return;
      }

      flushList(`flush-${key}`);
      elements.push(<p key={key}>{renderInline(line, key)}</p>);
    });
  });

  flushList("flush-final");

  return <div className="prose-article">{elements}</div>;
}
