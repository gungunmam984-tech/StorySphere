import "dotenv/config";
import { db, pool } from "./index";
import { authors, categories, comments, posts } from "./schema";

const img = (id: string) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1400`;

const avatar = (seed: string) =>
  `https://api.dicebear.com/7.x/notionists/svg?seed=${encodeURIComponent(seed)}&backgroundColor=f4ede4`;

async function main() {
  console.log("Seeding database...");

  await db.delete(comments);
  await db.delete(posts);
  await db.delete(authors);
  await db.delete(categories);

  const [tech, travel, lifestyle, finance, health] = await db
    .insert(categories)
    .values([
      {
        name: "Technology",
        slug: "technology",
        description:
          "Deep dives into artificial intelligence, software, gadgets and the digital trends shaping tomorrow.",
        icon: "💻",
      },
      {
        name: "Travel",
        slug: "travel",
        description:
          "Guides, itineraries and honest stories for curious travelers chasing the world's best experiences.",
        icon: "🌍",
      },
      {
        name: "Lifestyle",
        slug: "lifestyle",
        description:
          "Thoughtful essays on living intentionally, slowing down and designing a life you love.",
        icon: "🌿",
      },
      {
        name: "Finance",
        slug: "finance",
        description:
          "Practical, jargon-free money advice to help you save, invest and build lasting wealth.",
        icon: "💰",
      },
      {
        name: "Health",
        slug: "health",
        description:
          "Evidence-based wellness, fitness and nutrition guidance for a stronger mind and body.",
        icon: "🧘",
      },
    ])
    .returning();

  const [aanya, rohan, meera] = await db
    .insert(authors)
    .values([
      {
        name: "Aanya Sharma",
        slug: "aanya-sharma",
        role: "Senior Technology Editor",
        bio: "Aanya has spent the last decade covering emerging technology for leading publications. She specializes in AI, consumer software and the future of work, and loves translating complex ideas into practical takeaways for everyday readers.",
        avatarUrl: avatar("Aanya Sharma"),
        twitter: "@aanyawrites",
      },
      {
        name: "Rohan Verma",
        slug: "rohan-verma",
        role: "Travel & Lifestyle Writer",
        bio: "Rohan is a full-time traveler and storyteller who has visited over 40 countries. He writes about slow travel, sustainable adventures and the art of building an intentional life, drawing on lessons learned on the road.",
        avatarUrl: avatar("Rohan Verma"),
        twitter: "@rohanroams",
      },
      {
        name: "Dr. Meera Kapoor",
        slug: "meera-kapoor",
        role: "Health & Finance Contributor",
        bio: "Dr. Meera Kapoor blends a background in behavioral science with a passion for personal finance and wellbeing. She writes evidence-based guides that help readers build healthier habits and smarter money decisions.",
        avatarUrl: avatar("Meera Kapoor"),
        twitter: "@drmeerak",
      },
    ])
    .returning();

  const postsData = [
    {
      title: "The Rise of AI Copilots: How Machine Learning Is Reshaping Everyday Work",
      slug: "rise-of-ai-copilots",
      excerpt:
        "From writing code to drafting emails, AI copilots are quietly becoming the most transformative productivity tool of the decade. Here's what's really changing.",
      coverImage: img("8386440"),
      categoryId: tech.id,
      authorId: aanya.id,
      tags: ["artificial-intelligence", "productivity", "future-of-work"],
      readTimeMinutes: 7,
      featured: true,
      viewCount: 4820,
      content: `
Artificial intelligence has moved out of research labs and straight into the middle of our workdays. AI copilots — assistants embedded inside the tools we already use — are quietly rewriting what it means to be productive.

## What exactly is an AI copilot?

Unlike a standalone chatbot, a copilot lives inside your existing workflow. It watches the context of what you're doing — a spreadsheet, a code editor, an email draft — and offers suggestions, automations or entire first drafts on demand. The goal isn't to replace human judgment, but to remove the tedious 80% of a task so you can focus on the interesting 20%.

## Where copilots are making the biggest impact

1. **Software development.** Autocomplete has evolved into full function generation, test writing and bug triage, cutting routine coding time dramatically.
2. **Written communication.** Email, reports and presentations increasingly start life as an AI-generated draft that a human then edits and personalizes.
3. **Data analysis.** Natural-language queries against dashboards let non-technical teams ask "why did signups drop last week?" and get an instant, chart-backed answer.
4. **Customer support.** Suggested replies and automatic summarization are shortening resolution times without sacrificing the human touch.

## The skills that matter more now

As AI absorbs repetitive tasks, the premium shifts to skills machines are still bad at: judgment, taste, storytelling and asking the right question in the first place. Being a great "editor" of AI output is quickly becoming as valuable as being a great creator from scratch.

## How to get started without feeling overwhelmed

- Pick one repetitive task you dread and try automating just that.
- Treat the first output as a rough draft, not a final answer — always verify facts.
- Keep a swipe file of prompts that worked well for your specific job.
- Revisit your workflow every few months; the tools are improving fast.

AI copilots won't replace thoughtful professionals, but professionals who use them well are quickly outpacing those who don't. The most important step is simply starting — pick a small task today and see how much time you get back.
      `.trim(),
    },
    {
      title: "5 Underrated Productivity Apps Every Remote Worker Should Try in 2026",
      slug: "underrated-productivity-apps-2026",
      excerpt:
        "Beyond the usual suspects like Notion and Slack, these five lesser-known tools are quietly transforming how remote teams plan, focus and collaborate.",
      coverImage: img("5052875"),
      categoryId: tech.id,
      authorId: aanya.id,
      tags: ["productivity", "remote-work", "apps"],
      readTimeMinutes: 6,
      featured: false,
      viewCount: 2310,
      content: `
Remote work has produced an explosion of productivity tools, and it's easy to get stuck with the same handful of household names. Here are five apps that deserve far more attention.

## 1. Focus timers that adapt to your energy

Modern focus apps no longer use a rigid 25-minute Pomodoro. Instead, they learn your natural rhythm from calendar and activity data and suggest deep-work blocks when you're historically most alert.

## 2. Async video for faster decisions

Short, recorded video updates are replacing long status meetings. Teams report saving several hours a week simply by walking through a design or a bug on screen instead of scheduling a call across time zones.

## 3. Lightweight project trackers

Heavyweight project management suites can create as much overhead as they remove. A new wave of minimal trackers focuses on just three states — now, next, later — which is often all a small team actually needs.

## 4. Inbox triage assistants

Instead of another inbox client, these tools sit on top of your existing email and auto-sort messages into "needs a decision," "FYI" and "can wait," so you spend attention only where it matters.

## 5. Shared "second brain" notebooks

Team wikis are evolving into shared second brains that surface relevant notes automatically based on what you're currently working on, rather than requiring you to search for them.

## Choosing tools without tool fatigue

The biggest productivity killer isn't a lack of tools — it's too many of them. Before adding anything new, ask whether it replaces two existing tools or simply adds a third thing to check. The best remote workflows in 2026 are quietly boring: a handful of tools used consistently, not a dozen used halfheartedly.
      `.trim(),
    },
    {
      title: "Understanding Web3: A Beginner's Guide to Blockchain Beyond the Hype",
      slug: "understanding-web3-beginners-guide",
      excerpt:
        "Cutting through the noise, jargon and speculation to explain what blockchain technology actually does — and where it genuinely adds value.",
      coverImage: img("8849295"),
      categoryId: tech.id,
      authorId: aanya.id,
      tags: ["blockchain", "web3", "explainers"],
      readTimeMinutes: 8,
      featured: false,
      viewCount: 1875,
      content: `
Few technologies have generated as much excitement — and confusion — as blockchain. Stripped of hype, it's simply a new way to keep records that multiple parties can trust without a single central authority.

## The core idea in plain language

A blockchain is a shared, append-only ledger. Once a record is added, changing it would require rewriting every subsequent record across every copy of the ledger, which makes tampering extremely difficult. That's the entire innovation — everything else is built on top of it.

## Where it genuinely helps

- **Cross-border payments** that settle without waiting on multiple banking intermediaries.
- **Provenance tracking** for goods, art and documents, where proving authenticity matters.
- **Programmable agreements** (smart contracts) that execute automatically when conditions are met, reducing the need for manual enforcement.

## Where the hype has outpaced the substance

Not every problem needs a blockchain. If a trusted central party already exists and works well, adding decentralization mostly adds cost and complexity. Speculative trading has also overshadowed genuine utility, making it harder for newcomers to separate signal from noise.

## Questions worth asking before you invest time or money

1. Does this actually need to be decentralized, or is that just marketing?
2. Who benefits if the token price rises, independent of the underlying technology's usefulness?
3. What happens to my funds or data if the project disappears tomorrow?

## The bottom line

Treat Web3 as one tool among many, not a religion. The technology has real, narrow use cases today and may find more as it matures — but healthy skepticism is still your best asset when the vocabulary gets ahead of the value.
      `.trim(),
    },
    {
      title: "Hidden Gems of Southeast Asia: 7 Destinations Off the Tourist Trail",
      slug: "hidden-gems-southeast-asia",
      excerpt:
        "Skip the crowds. These seven destinations across Southeast Asia deliver the scenery and culture everyone chases — without the queues.",
      coverImage: img("19828769"),
      categoryId: travel.id,
      authorId: rohan.id,
      tags: ["southeast-asia", "hidden-gems", "itinerary"],
      readTimeMinutes: 9,
      featured: true,
      viewCount: 5230,
      content: `
Southeast Asia's headline destinations deserve their fame, but venture a little further and you'll find places just as beautiful with a fraction of the visitors.

## 1. Kampot, Cambodia

A sleepy riverside town famous for its pepper farms and colonial architecture, Kampot is perfect for slow mornings on a rooftop café and sunset boat rides past mangroves.

## 2. Nusa Penida's quieter east coast

Everyone photographs Kelingking Beach, but the island's eastern villages offer the same dramatic cliffs with almost no one else around at sunrise.

## 3. Kep, Cambodia

Twenty minutes from Kampot, Kep is known for its crab market and abandoned French villas slowly being reclaimed by jungle — an atmospheric, photogenic detour.

## 4. Hsipaw, Myanmar

Trekking routes here wind through Shan hill villages with none of the crowds found in more famous trekking hubs elsewhere in the region.

## 5. Con Dao Islands, Vietnam

Once a prison colony, this archipelago is now one of Vietnam's best-kept secrets for pristine beaches and sea turtle nesting sites.

## 6. Sipadan's neighboring islands, Malaysia

Rather than fighting for a Sipadan diving permit, base yourself on nearby Mabul or Kapalai for equally spectacular muck diving.

## 7. Battambang, Cambodia

Cambodia's charming second city offers colonial architecture, a bizarre bamboo train and some of the country's best contemporary art scene, minus the Siem Reap crowds.

## Planning tips

Travel just before or after peak season, base yourself in a smaller town and add one extra local bus ride to your itinerary — that's usually all it takes to leave the crowds behind.
      `.trim(),
    },
    {
      title: "The Ultimate Backpacking Guide for Solo Travelers on a Budget",
      slug: "backpacking-guide-solo-travelers-budget",
      excerpt:
        "Everything you need to plan a safe, affordable and unforgettable solo backpacking trip — from packing lists to money-saving routes.",
      coverImage: img("17980012"),
      categoryId: travel.id,
      authorId: rohan.id,
      tags: ["backpacking", "budget-travel", "solo-travel"],
      readTimeMinutes: 10,
      featured: false,
      viewCount: 3410,
      content: `
Solo backpacking remains one of the best ways to see the world on a modest budget while building genuine independence and confidence.

## Setting a realistic budget

Track three categories separately: accommodation, food and transport. Most first-time backpackers overspend on transport by booking too many flights instead of overland routes — buses and trains are often a fraction of the cost and show you far more of the country.

## What actually belongs in your pack

- One weatherproof jacket that layers over everything else
- A universal sink stopper and travel detergent for washing clothes on the go
- A power bank rated for at least two full phone charges
- A lightweight padlock for hostel lockers
- Copies of key documents stored both on paper and in the cloud

## Staying safe as a solo traveler

Share your rough itinerary with someone at home, trust your instincts over politeness, and choose accommodation with recent reviews mentioning safety specifically, not just cleanliness.

## Meeting people without a built-in group

Hostels with communal kitchens or free walking tours are the easiest way to make friends fast. Say yes to the first invitation you get in a new city — it usually leads to the next one.

## Making your money last longer

Cook simple meals a few nights a week, travel overnight on buses or trains to save a night's accommodation, and always negotiate politely for stays longer than three nights.

Solo backpacking teaches you to trust yourself in a way few other experiences can. Start with a modest two-week trip before committing to a longer journey — confidence builds quickly once you're on the road.
      `.trim(),
    },
    {
      title: "How to Travel Sustainably Without Sacrificing Adventure",
      slug: "travel-sustainably-without-sacrificing-adventure",
      excerpt:
        "Sustainable travel doesn't mean staying home. Here's how to reduce your footprint while still chasing unforgettable experiences.",
      coverImage: img("13986672"),
      categoryId: travel.id,
      authorId: rohan.id,
      tags: ["sustainable-travel", "eco-tourism", "responsible-travel"],
      readTimeMinutes: 7,
      featured: false,
      viewCount: 1980,
      content: `
Traveling responsibly is less about giving things up and more about being intentional with the choices you already make.

## Choose overland routes when you can

Trains and buses produce a fraction of the emissions of short-haul flights, and they usually show you more of the country along the way.

## Stay longer, move less

Rather than a new city every two days, staying five to seven nights in fewer places reduces transport emissions and lets you support local businesses more meaningfully.

## Spend where it counts

Book locally owned guesthouses and tour operators rather than large international chains — more of your money stays in the community you're visiting.

## Pack to reduce waste

A reusable water bottle with a filter, a cloth bag and a bar of solid shampoo eliminate a surprising amount of single-use plastic over a multi-week trip.

## Respect wildlife and culture

Avoid any attraction that allows direct contact with wild animals, and take time to learn a handful of local phrases — both signal respect and often open doors that money can't.

## The bigger picture

No trip is perfectly carbon-neutral, but small, consistent choices compound. Sustainable travel is a direction, not a destination — every improvement counts.
      `.trim(),
    },
    {
      title: "Minimalism in 2026: Decluttering Your Life for Lasting Happiness",
      slug: "minimalism-2026-decluttering-happiness",
      excerpt:
        "Minimalism has evolved beyond white walls and capsule wardrobes. Here's a grounded, realistic approach to owning less and living more.",
      coverImage: img("7407954"),
      categoryId: lifestyle.id,
      authorId: rohan.id,
      tags: ["minimalism", "decluttering", "intentional-living"],
      readTimeMinutes: 6,
      featured: true,
      viewCount: 2990,
      content: `
Minimalism isn't about owning as little as possible — it's about making sure everything you own actually earns its place in your life.

## Start with one drawer, not the whole house

Trying to declutter an entire home in a weekend leads to burnout. Pick a single drawer or shelf, decide what stays, and let the momentum build naturally from there.

## The "one year" rule

If you haven't used or worn something in the last year and it isn't seasonal or sentimental, it's a strong candidate to donate or sell.

## Digital clutter counts too

Unsubscribe from newsletters you skim without reading, delete apps you open out of habit rather than need, and archive old files instead of letting them pile up on your desktop.

## Buying less, choosing better

Minimalism isn't anti-shopping — it's pro-intention. Before a purchase, ask whether the item replaces something you already own or simply adds to the pile.

## The payoff beyond a tidy home

People who declutter consistently report less daily decision fatigue, faster mornings and more mental space for the things that actually matter. A simpler home tends to lead to a calmer mind — not because objects are inherently bad, but because fewer choices free up energy for better ones.
      `.trim(),
    },
    {
      title: "The Art of Slow Living: Reclaiming Your Time in a Fast World",
      slug: "art-of-slow-living",
      excerpt:
        "Slow living isn't about doing less — it's about being fully present for what you choose to do. Here's how to build it into a busy life.",
      coverImage: img("7671669"),
      categoryId: lifestyle.id,
      authorId: rohan.id,
      tags: ["slow-living", "mindfulness", "intentional-living"],
      readTimeMinutes: 6,
      featured: false,
      viewCount: 2140,
      content: `
Slow living has become a popular phrase, but at its core it's a simple idea: choosing quality of attention over quantity of activity.

## It's not about moving to the countryside

You don't need a farmhouse or a four-day work week to live slowly. It's a mindset you can practice inside an ordinary, busy schedule — one meal, one conversation, one commute at a time.

## Build in transition time

Rushing straight from one commitment to the next leaves no room to actually process what just happened. Even five unscheduled minutes between meetings can dramatically reduce the feeling of being perpetually behind.

## Single-task on purpose

Multitasking rarely saves time — it mostly splits your attention across everything and gives your full focus to nothing. Try doing one thing at a time for a single day and notice how different it feels.

## Protect a daily ritual

A slow morning coffee, an evening walk without your phone, or fifteen quiet minutes before bed all signal to your nervous system that the day has natural beginnings and endings.

## Slow living as a practice, not a destination

Some days will still be fast and full — that's normal. The goal isn't perfection, it's returning, again and again, to a slower, more intentional pace whenever you notice you've drifted from it.
      `.trim(),
    },
    {
      title: "Personal Finance 101: Building an Emergency Fund That Actually Works",
      slug: "personal-finance-101-emergency-fund",
      excerpt:
        "An emergency fund is the foundation of financial security. Here's exactly how much to save, where to keep it, and how to build it faster.",
      coverImage: img("33785776"),
      categoryId: finance.id,
      authorId: meera.id,
      tags: ["personal-finance", "saving", "emergency-fund"],
      readTimeMinutes: 7,
      featured: true,
      viewCount: 3760,
      content: `
Before investing a single rupee or dollar in the market, financial advisors almost universally agree on one first step: build an emergency fund.

## How much do you actually need?

A common guideline is three to six months of essential expenses — rent, utilities, groceries and minimum debt payments. Freelancers or single-income households often lean toward the higher end for extra security.

## Where to keep it

Your emergency fund should be boring by design: a high-yield savings account you can access within a day or two, not invested in stocks where it could lose value exactly when you need it most.

## Building it faster without misery

- Automate a fixed transfer the day you get paid, before you have a chance to spend it.
- Redirect windfalls — tax refunds, bonuses, cash gifts — straight into the fund.
- Try a temporary "no-spend month" on one discretionary category and bank the difference.

## What counts as a real emergency

A genuine emergency is unexpected, necessary and urgent — a medical bill, a job loss, an essential car repair. A holiday sale on something you wanted is not an emergency, however convincing it feels in the moment.

## Rebuilding after you use it

If you dip into the fund, treat replenishing it as a top financial priority before resuming other savings goals. Consider the fund "borrowed from your future self," to be paid back promptly.

An emergency fund won't make you rich, but it will keep a single bad month from turning into a bad year — and that peace of mind is worth far more than the interest it earns.
      `.trim(),
    },
    {
      title: "Investing for Beginners: Index Funds vs. Individual Stocks",
      slug: "investing-beginners-index-funds-vs-stocks",
      excerpt:
        "Trying to decide between picking individual stocks and buying a diversified index fund? Here's an honest, balanced comparison.",
      coverImage: img("33785779"),
      categoryId: finance.id,
      authorId: meera.id,
      tags: ["investing", "index-funds", "stocks"],
      readTimeMinutes: 8,
      featured: false,
      viewCount: 2870,
      content: `
New investors often face the same early decision: try to pick winning stocks, or buy a fund that owns the whole market. Both approaches can work — but they suit very different temperaments.

## The case for index funds

Index funds buy a small slice of hundreds or thousands of companies at once, spreading risk automatically. Decades of data show that the majority of actively managed funds fail to beat a simple low-cost index over the long run, largely due to fees and the difficulty of consistently picking winners.

## The case for individual stocks

Picking individual companies can outperform the market, but it requires real research time, emotional discipline during downturns, and acceptance that any single company can fail entirely. It suits investors who enjoy the process and can honestly separate research from speculation.

## A practical middle ground

Many experienced investors hold a core of low-cost index funds for the bulk of their portfolio, with a small "satellite" allocation — often 5-10% — in individual stocks they've researched and are comfortable losing entirely.

## Questions to ask yourself before choosing

1. Do I have the time and genuine interest to research individual companies regularly?
2. Can I emotionally handle watching a single stock drop 40% without panic-selling?
3. Am I trying to beat the market, or simply grow my money reliably over decades?

## The most important factor either way

Consistency beats cleverness. An investor who contributes a modest amount every month to a diversified fund for twenty years will typically outperform someone who invests sporadically, however skilled their stock picks are.
      `.trim(),
    },
    {
      title: "The Science of Sleep: How to Optimize Your Rest for Peak Performance",
      slug: "science-of-sleep-optimize-rest",
      excerpt:
        "Sleep is the most underrated performance-enhancing habit available to anyone. Here's what the research says about getting more of it, and better.",
      coverImage: img("3807760"),
      categoryId: health.id,
      authorId: meera.id,
      tags: ["sleep", "wellness", "productivity"],
      readTimeMinutes: 7,
      featured: false,
      viewCount: 3120,
      content: `
No supplement, productivity app or morning routine comes close to the performance benefits of consistent, quality sleep.

## Why sleep quality matters more than duration alone

Sleep occurs in cycles of roughly 90 minutes, moving through light, deep and REM stages. Deep sleep restores the body; REM sleep consolidates memory and emotional processing. Waking mid-cycle — even after eight hours — can leave you groggier than a slightly shorter sleep aligned to a full cycle.

## Building a wind-down routine that works

- Dim lights and lower screen brightness at least 60 minutes before bed to support natural melatonin release.
- Keep your bedroom cool, ideally between 18-20°C (65-68°F).
- Avoid caffeine within eight hours of bedtime — it has a longer half-life than most people expect.
- Get bright natural light within 30 minutes of waking to anchor your circadian rhythm.

## What to do about a racing mind at bedtime

A five-minute "brain dump" — writing down tomorrow's tasks and worries before lights out — measurably reduces the time it takes to fall asleep by giving your mind permission to stop rehearsing them.

## Naps: friend or foe?

Short naps of 10-20 minutes before 3pm can restore alertness without disrupting nighttime sleep. Longer or later naps often make it harder to fall asleep that night, creating a cycle of fragmented rest.

## The bottom line

Treat sleep as a non-negotiable input to performance, not a reward for finishing everything else. Protecting seven to nine hours consistently will do more for your focus, mood and health than almost any other single habit.
      `.trim(),
    },
    {
      title: "Mindful Eating: A Practical Guide to a Healthier Relationship with Food",
      slug: "mindful-eating-practical-guide",
      excerpt:
        "Mindful eating isn't a diet — it's a set of simple habits that help you enjoy food more while naturally supporting your health goals.",
      coverImage: img("6793199"),
      categoryId: health.id,
      authorId: meera.id,
      tags: ["nutrition", "mindfulness", "wellness"],
      readTimeMinutes: 6,
      featured: false,
      viewCount: 1650,
      content: `
Mindful eating shifts the focus from strict rules to genuine attention — noticing what, why and how you eat, without judgment.

## Slow down the first three bites

Research suggests it takes roughly 20 minutes for fullness signals to reach the brain. Simply slowing down for the first few bites of a meal — putting your fork down between them — gives your body a better chance to keep pace.

## Remove distractions at meals

Eating in front of a screen makes it easy to miss your body's fullness cues entirely. Even one distraction-free meal a day can noticeably improve how satisfied you feel afterward.

## Distinguish real hunger from other triggers

Before eating, a quick pause to ask "am I actually hungry, or bored, stressed or tired?" helps separate physical hunger from emotional triggers, without requiring you to ignore either.

## Let go of "good" and "bad" food labels

Moralizing food often backfires, leading to guilt-driven cycles of restriction and overeating. Every food can fit into a healthy pattern; what matters most is your overall pattern over weeks, not any single meal.

## A simple practice to start today

Choose one meal a day to eat without your phone, plate seated at a table rather than standing, and take three slow breaths before the first bite. Small, consistent shifts like this compound into a genuinely healthier relationship with food over time.
      `.trim(),
    },
  ];

  const insertedPosts = await db.insert(posts).values(postsData).returning();

  const sampleComments = [
    {
      name: "Priya N.",
      email: "priya@example.com",
      message: "This was such a helpful breakdown — bookmarking to re-read later!",
    },
    {
      name: "Daniel K.",
      email: "daniel@example.com",
      message: "Really well written. I tried the first tip this week and it already made a difference.",
    },
    {
      name: "Sam O.",
      email: "sam@example.com",
      message: "Would love a follow-up post that goes even deeper on this topic.",
    },
  ];

  for (const post of insertedPosts.slice(0, 6)) {
    await db.insert(comments).values(
      sampleComments.map((c) => ({
        postId: post.id,
        ...c,
      })),
    );
  }

  console.log(`Seeded ${insertedPosts.length} posts across 5 categories and 3 authors.`);
  await pool.end();
}

main().catch(async (error) => {
  console.error(error);
  await pool.end();
  process.exit(1);
});
