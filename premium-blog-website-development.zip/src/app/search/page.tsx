import Link from "next/link";
import type { Metadata } from "next";
import PostCard from "@/components/PostCard";
import { searchPosts } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Search",
  description: "Search articles on Lumière Journal.",
};

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const posts = q ? await searchPosts(q) : [];

  return (
    <main className="mx-auto max-w-4xl px-6 py-16">
      <p className="text-sm font-semibold uppercase tracking-wider text-amber-700">Search</p>
      <h1 className="mt-2 font-serif text-4xl font-bold text-stone-950">Find an article</h1>

      <form action="/search" className="mt-8 flex overflow-hidden rounded-full border border-stone-200 shadow-sm">
        <input
          type="text"
          name="q"
          defaultValue={q ?? ""}
          placeholder="Search by title, topic or keyword..."
          className="w-full px-5 py-3.5 text-sm outline-none"
        />
        <button type="submit" className="whitespace-nowrap bg-stone-900 px-6 py-3.5 text-sm font-semibold text-white hover:bg-amber-700">
          Search
        </button>
      </form>

      {q && (
        <p className="mt-6 text-sm text-stone-500">
          {posts.length} result{posts.length === 1 ? "" : "s"} for &ldquo;{q}&rdquo;
        </p>
      )}

      <div className="mt-8 grid gap-6 sm:grid-cols-2">
        {posts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>

      {q && posts.length === 0 && (
        <div className="mt-6 rounded-2xl border border-dashed border-stone-300 p-12 text-center text-stone-500">
          No articles matched your search.{" "}
          <Link href="/blog" className="font-semibold text-amber-700 hover:underline">
            Browse all articles
          </Link>{" "}
          instead.
        </div>
      )}
    </main>
  );
}
