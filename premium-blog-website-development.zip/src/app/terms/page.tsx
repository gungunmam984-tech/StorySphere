import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "Read the terms of service governing your use of Lumière Journal.",
};

export default function TermsPage() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-16">
      <p className="text-sm font-semibold uppercase tracking-wider text-amber-700">Legal</p>
      <h1 className="mt-2 font-serif text-4xl font-bold text-stone-950">Terms of Service</h1>
      <p className="mt-3 text-sm text-stone-500">Last updated: January 2026</p>

      <div className="prose-article mt-10">
        <h2>1. Acceptance of terms</h2>
        <p>
          By accessing and using Lumière Journal, you agree to be bound by these Terms of
          Service. If you do not agree with any part of these terms, please do not use this site.
        </p>

        <h2>2. Use of content</h2>
        <p>
          All articles, images and other content on this site are provided for personal,
          non-commercial reading unless otherwise noted. You may share links to our articles, but
          reproducing full articles elsewhere without permission is not permitted.
        </p>

        <h2>3. User-submitted content</h2>
        <p>
          When you submit a comment or contact message, you grant us the right to display and
          moderate that content on our site. We reserve the right to remove any content that is
          abusive, spammy or otherwise inappropriate.
        </p>

        <h2>4. No professional advice</h2>
        <p>
          Articles on this site — including those about health, finance and travel — are for
          informational purposes only and do not constitute professional advice. Always consult a
          qualified professional before making significant decisions.
        </p>

        <h2>5. Limitation of liability</h2>
        <p>
          Lumière Journal is provided "as is" without warranties of any kind. We are not liable
          for any damages arising from your use of, or inability to use, this site.
        </p>

        <h2>6. Changes to these terms</h2>
        <p>
          We may revise these terms at any time. Continued use of the site after changes are
          posted constitutes acceptance of the revised terms.
        </p>

        <h2>7. Contact</h2>
        <p>
          Questions about these terms can be sent through our{" "}
          <a href="/contact" className="font-semibold text-amber-700 underline">contact page</a>.
        </p>
      </div>
    </main>
  );
}
