import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import { getAllAuthors } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "About Us",
  description: "Learn about Lumière Journal, our mission and the writers behind our premium articles.",
};

const values = [
  {
    icon: "🔍",
    title: "Depth over noise",
    text: "Every article goes through real research and multiple drafts. We'd rather publish once a week and be worth your time than chase clicks daily.",
  },
  {
    icon: "🤝",
    title: "Honest, no-hype writing",
    text: "We avoid exaggerated claims and clickbait. If something is uncertain or nuanced, we say so.",
  },
  {
    icon: "🌱",
    title: "Practical over theoretical",
    text: "Every piece ends with something you can actually apply — a habit, a checklist or a decision framework.",
  },
];

export default async function AboutPage() {
  const authors = await getAllAuthors();

  return (
    <main>
      <section className="border-b border-amber-100 bg-gradient-to-b from-amber-50/60 to-[#fdfaf4]">
        <div className="mx-auto max-w-4xl px-6 py-20 text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-amber-700">About Lumière Journal</p>
          <h1 className="mt-3 font-serif text-4xl font-bold text-stone-950 sm:text-5xl">
            Thoughtful writing for a distracted world.
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-stone-600">
            Lumière Journal started with a simple idea: most online content is written to be
            skimmed, not read. We wanted to build the opposite — a small, premium publication
            covering technology, travel, lifestyle, finance and health, written for readers who
            want real depth.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-6 py-16">
        <div className="grid gap-10 sm:grid-cols-2">
          <div className="relative aspect-[4/3] overflow-hidden rounded-3xl">
            <Image
              src="https://images.pexels.com/photos/3861563/pexels-photo-3861563.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200"
              alt="The Lumière Journal team collaborating"
              fill
              className="object-cover"
            />
          </div>
          <div className="flex flex-col justify-center">
            <p className="text-sm font-semibold uppercase tracking-wider text-amber-700">Our story</p>
            <h2 className="mt-2 font-serif text-3xl font-bold text-stone-950">
              Built by writers, for readers
            </h2>
            <p className="mt-4 text-stone-600">
              We're a small, independent team of three writers with backgrounds spanning
              technology journalism, full-time travel and behavioral science. Rather than
              scaling to hundreds of contributors, we've chosen to stay small and hold every
              article to the same high bar.
            </p>
            <p className="mt-4 text-stone-600">
              Today, thousands of readers rely on Lumière Journal every week for articles that
              respect both their time and their intelligence.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-6xl px-6">
          <div className="text-center">
            <p className="text-sm font-semibold uppercase tracking-wider text-amber-700">What we stand for</p>
            <h2 className="mt-2 font-serif text-3xl font-bold text-stone-950">Our editorial values</h2>
          </div>
          <div className="mt-10 grid gap-6 sm:grid-cols-3">
            {values.map((v) => (
              <div key={v.title} className="rounded-2xl border border-stone-100 p-6 text-center">
                <span className="text-3xl">{v.icon}</span>
                <h3 className="mt-3 font-serif text-lg font-semibold text-stone-900">{v.title}</h3>
                <p className="mt-2 text-sm text-stone-600">{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-16">
        <div className="text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-amber-700">The team</p>
          <h2 className="mt-2 font-serif text-3xl font-bold text-stone-950">Meet the writers</h2>
        </div>
        <div className="mt-10 grid gap-8 sm:grid-cols-3">
          {authors.map((author) => (
            <Link
              key={author.id}
              href={`/author/${author.slug}`}
              className="group flex flex-col items-center rounded-2xl border border-stone-100 bg-white p-8 text-center transition hover:-translate-y-1 hover:shadow-lg"
            >
              <Image
                src={author.avatarUrl}
                alt={author.name}
                width={88}
                height={88}
                className="h-22 w-22 rounded-full border border-stone-200 bg-amber-50"
              />
              <h3 className="mt-4 font-serif text-lg font-semibold text-stone-900 group-hover:text-amber-700">
                {author.name}
              </h3>
              <p className="mt-1 text-xs font-semibold uppercase tracking-wider text-amber-700">{author.role}</p>
              <p className="mt-3 line-clamp-3 text-sm text-stone-600">{author.bio}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="border-t border-amber-100 bg-amber-50/60 py-16 text-center">
        <h2 className="font-serif text-2xl font-bold text-stone-950">Want to get in touch?</h2>
        <p className="mt-2 text-stone-600">We read every message — pitches, feedback and everything in between.</p>
        <Link
          href="/contact"
          className="mt-6 inline-block rounded-full bg-stone-900 px-7 py-3.5 text-sm font-semibold text-white transition hover:bg-amber-700"
        >
          Contact us
        </Link>
      </section>
    </main>
  );
}
