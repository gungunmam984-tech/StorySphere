import { db } from "@/db";
import { comments } from "@/db/schema";
import { NextResponse } from "next/server";
import { z } from "zod";

const schema = z.object({
  postId: z.number().int().positive(),
  name: z.string().trim().min(1, "Name is required").max(120),
  email: z.string().trim().email("Please enter a valid email address."),
  message: z.string().trim().min(2, "Comment is too short").max(2000),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = schema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? "Invalid input" },
        { status: 400 },
      );
    }

    const [comment] = await db.insert(comments).values(parsed.data).returning();

    return NextResponse.json({ success: true, comment });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Something went wrong. Please try again." }, { status: 500 });
  }
}
