import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import PostCard from "@/components/PostCard";
import PostContent from "@/components/PostContent";
import CommentForm from "@/components/CommentForm";
import { formatDate, formatNumber, tagLabel } from "@/lib/format";
import {
  getCommentsForPost,
  getPostBySlug,
  getRelatedPosts,
  incrementPostViews,
} from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = await getPostBySlug(slug);
  if (!post) return { title: "Article not found" };

  return {
    title: post.title,
    description: post.excerpt,
    openGraph: {
      title: post.title,
      description: post.excerpt,
      images: [post.coverImage],
      type: "article",
    },
  };
}

export default async function PostPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = await getPostBySlug(slug);

  if (!post) notFound();

  incrementPostViews(post.id).catch(() => {});

  const [related, postComments] = await Promise.all([
    getRelatedPosts(post.id, post.category.id, 3),
    getCommentsForPost(post.id),
  ]);

  return (
    <main>
      <article className="mx-auto max-w-3xl px-6 py-12">
        <nav className="flex flex-wrap items-center gap-1 text-xs text-stone-500">
          <Link href="/" className="hover:text-amber-700">Home</Link>
          <span>/</span>
          <Link href="/blog" className="hover:text-amber-700">Blog</Link>
          <span>/</span>
          <Link href={`/category/${post.category.slug}`} className="hover:text-amber-700">
            {post.category.name}
          </Link>
        </nav>

        <Link
          href={`/category/${post.category.slug}`}
          className="mt-6 inline-block rounded-full bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-700"
        >
          {post.category.icon} {post.category.name}
        </Link>

        <h1 className="mt-4 font-serif text-3xl font-bold leading-tight text-stone-950 sm:text-4xl lg:text-5xl">
          {post.title}
        </h1>

        <p className="mt-5 text-lg leading-relaxed text-stone-600">{post.excerpt}</p>

        <div className="mt-6 flex flex-wrap items-center gap-4 border-y border-stone-200 py-4">
          <Link href={`/author/${post.author.slug}`} className="flex items-center gap-3">
            <Image
              src={post.author.avatarUrl}
              alt={post.author.name}
              width={44}
              height={44}
              className="h-11 w-11 rounded-full border border-stone-200 bg-amber-50"
            />
            <div>
              <p className="text-sm font-semibold text-stone-900">{post.author.name}</p>
              <p className="text-xs text-stone-500">{post.author.role}</p>
            </div>
          </Link>
          <div className="ml-auto flex items-center gap-3 text-xs text-stone-500">
            <span>{formatDate(post.publishedAt)}</span>
            <span>·</span>
            <span>{post.readTimeMinutes} min read</span>
            <span>·</span>
            <span>👁 {formatNumber(post.viewCount)} views</span>
          </div>
        </div>

        <div className="relative mt-8 aspect-[16/9] w-full overflow-hidden rounded-2xl">
          <Image src={post.coverImage} alt={post.title} fill priority className="object-cover" />
        </div>

        <div className="mt-10">
          <PostContent content={post.content} />
        </div>

        <div className="mt-10 flex flex-wrap gap-2 border-t border-stone-200 pt-6">
          {post.tags.map((tag) => (
            <Link
              key={tag}
              href={`/blog?tag=${tag}`}
              className="rounded-full bg-amber-50 px-3 py-1.5 text-xs font-semibold text-amber-800 hover:bg-amber-100"
            >
              #{tagLabel(tag)}
            </Link>
          ))}
        </div>

        <div className="mt-10 flex flex-col gap-4 rounded-2xl border border-stone-100 bg-white p-6 sm:flex-row sm:items-center">
          <Image
            src={post.author.avatarUrl}
            alt={post.author.name}
            width={64}
            height={64}
            className="h-16 w-16 rounded-full border border-stone-200 bg-amber-50"
          />
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-amber-700">Written by</p>
            <Link href={`/author/${post.author.slug}`} className="font-serif text-xl font-semibold text-stone-900 hover:text-amber-700">
              {post.author.name}
            </Link>
            <p className="mt-1 text-sm text-stone-600">{post.author.role}</p>
          </div>
          <Link
            href={`/author/${post.author.slug}`}
            className="rounded-full border border-stone-300 px-5 py-2 text-sm font-semibold text-stone-800 hover:border-amber-400 hover:text-amber-700 sm:ml-auto"
          >
            View profile
          </Link>
        </div>

        <section className="mt-14">
          <h2 className="font-serif text-2xl font-bold text-stone-950">
            Comments ({postComments.length})
          </h2>
          <div className="mt-6 flex flex-col gap-5">
            {postComments.map((comment) => (
              <div key={comment.id} className="rounded-2xl border border-stone-100 bg-white p-5">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-stone-900">{comment.name}</p>
                  <p className="text-xs text-stone-400">{formatDate(comment.createdAt)}</p>
                </div>
                <p className="mt-2 text-sm text-stone-600">{comment.message}</p>
              </div>
            ))}
          </div>
          <div className="mt-6">
            <CommentForm postId={post.id} />
          </div>
        </section>
      </article>

      {related.length > 0 && (
        <section className="border-t border-stone-100 bg-white py-14">
          <div className="mx-auto max-w-7xl px-6">
            <h2 className="font-serif text-2xl font-bold text-stone-950">More in {post.category.name}</h2>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {related.map((r) => (
                <PostCard key={r.id} post={r} />
              ))}
            </div>
          </div>
        </section>
      )}
    </main>
  );
}
