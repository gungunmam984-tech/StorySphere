import Link from "next/link";
import type { Metadata } from "next";
import PostCard from "@/components/PostCard";
import {
  getAllCategories,
  getAllPosts,
  getAllTags,
  getPostsByCategorySlug,
  getPostsByTag,
  searchPosts,
} from "@/lib/queries";
import { tagLabel } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "All Articles",
  description: "Browse every article published on Lumière Journal across technology, travel, lifestyle, finance and health.",
};

export default async function BlogPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; tag?: string; q?: string }>;
}) {
  const params = await searchParams;
  const [categories, tags] = await Promise.all([getAllCategories(), getAllTags()]);

  let posts;
  if (params.q) {
    posts = await searchPosts(params.q);
  } else if (params.category) {
    posts = await getPostsByCategorySlug(params.category);
  } else if (params.tag) {
    posts = await getPostsByTag(params.tag);
  } else {
    posts = await getAllPosts();
  }

  const heading = params.q
    ? `Search results for "${params.q}"`
    : params.category
      ? categories.find((c) => c.slug === params.category)?.name ?? "Articles"
      : params.tag
        ? `#${tagLabel(params.tag)}`
        : "All Articles";

  return (
    <main className="mx-auto max-w-7xl px-6 py-14">
      <div className="max-w-2xl">
        <p className="text-sm font-semibold uppercase tracking-wider text-amber-700">The Archive</p>
        <h1 className="mt-2 font-serif text-4xl font-bold text-stone-950">{heading}</h1>
        <p className="mt-3 text-stone-600">
          {posts.length} article{posts.length === 1 ? "" : "s"} found. Explore by category or tag below.
        </p>
      </div>

      <div className="mt-8 flex flex-wrap gap-2">
        <Link
          href="/blog"
          className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
            !params.category && !params.tag && !params.q
              ? "bg-stone-900 text-white"
              : "border border-stone-200 text-stone-700 hover:border-amber-300"
          }`}
        >
          All
        </Link>
        {categories.map((category) => (
          <Link
            key={category.id}
            href={`/blog?category=${category.slug}`}
            className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
              params.category === category.slug
                ? "bg-stone-900 text-white"
                : "border border-stone-200 text-stone-700 hover:border-amber-300"
            }`}
          >
            {category.icon} {category.name}
          </Link>
        ))}
      </div>

      <div className="mt-10 grid gap-10 lg:grid-cols-[2fr_1fr]">
        <div>
          {posts.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-stone-300 p-12 text-center text-stone-500">
              No articles found. Try a different filter or{" "}
              <Link href="/blog" className="font-semibold text-amber-700 hover:underline">
                view all articles
              </Link>
              .
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2">
              {posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </div>

        <aside>
          <div className="rounded-2xl border border-stone-100 bg-white p-6">
            <h3 className="font-serif text-lg font-semibold text-stone-900">Popular tags</h3>
            <div className="mt-4 flex flex-wrap gap-2">
              {tags.map((tag) => (
                <Link
                  key={tag}
                  href={`/blog?tag=${tag}`}
                  className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                    params.tag === tag
                      ? "bg-amber-600 text-white"
                      : "bg-amber-50 text-amber-800 hover:bg-amber-100"
                  }`}
                >
                  #{tagLabel(tag)}
                </Link>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
}
