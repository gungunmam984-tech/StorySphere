import Link from "next/link";

export default function NotFound() {
  return (
    <main className="mx-auto flex max-w-2xl flex-col items-center px-6 py-28 text-center">
      <span className="text-6xl">📖</span>
      <h1 className="mt-6 font-serif text-4xl font-bold text-stone-950">Page not found</h1>
      <p className="mt-3 text-stone-600">
        The page you're looking for may have been moved or doesn't exist. Let's get you back on track.
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-4">
        <Link href="/" className="rounded-full bg-stone-900 px-6 py-3 text-sm font-semibold text-white hover:bg-amber-700">
          Back to home
        </Link>
        <Link href="/blog" className="rounded-full border border-stone-300 px-6 py-3 text-sm font-semibold text-stone-800 hover:border-amber-400">
          Browse articles
        </Link>
      </div>
    </main>
  );
}
