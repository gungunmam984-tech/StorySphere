import { notFound } from "next/navigation";
import type { Metadata } from "next";
import PostCard from "@/components/PostCard";
import { getAllCategories, getCategoryBySlug, getPostsByCategorySlug } from "@/lib/queries";
import Link from "next/link";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const category = await getCategoryBySlug(slug);
  if (!category) return { title: "Category not found" };
  return {
    title: category.name,
    description: category.description,
  };
}

export default async function CategoryPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const [category, posts, allCategories] = await Promise.all([
    getCategoryBySlug(slug),
    getPostsByCategorySlug(slug),
    getAllCategories(),
  ]);

  if (!category) notFound();

  return (
    <main>
      <section className="border-b border-amber-100 bg-gradient-to-b from-amber-50/60 to-[#fdfaf4]">
        <div className="mx-auto max-w-4xl px-6 py-16 text-center">
          <span className="text-5xl">{category.icon}</span>
          <h1 className="mt-4 font-serif text-4xl font-bold text-stone-950">{category.name}</h1>
          <p className="mx-auto mt-4 max-w-xl text-stone-600">{category.description}</p>
          <p className="mt-3 text-sm font-semibold text-amber-700">
            {posts.length} article{posts.length === 1 ? "" : "s"}
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-14">
        <div className="mb-8 flex flex-wrap gap-2">
          {allCategories.map((c) => (
            <Link
              key={c.id}
              href={`/category/${c.slug}`}
              className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                c.slug === slug
                  ? "bg-stone-900 text-white"
                  : "border border-stone-200 text-stone-700 hover:border-amber-300"
              }`}
            >
              {c.icon} {c.name}
            </Link>
          ))}
        </div>

        {posts.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-stone-300 p-12 text-center text-stone-500">
            No articles in this category yet. Check back soon!
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
