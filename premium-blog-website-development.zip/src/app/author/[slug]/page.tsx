import Image from "next/image";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import PostCard from "@/components/PostCard";
import { getAuthorBySlug, getPostsByAuthorSlug } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const author = await getAuthorBySlug(slug);
  if (!author) return { title: "Author not found" };
  return {
    title: author.name,
    description: author.bio,
  };
}

export default async function AuthorPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const [author, posts] = await Promise.all([
    getAuthorBySlug(slug),
    getPostsByAuthorSlug(slug),
  ]);

  if (!author) notFound();

  return (
    <main>
      <section className="border-b border-amber-100 bg-gradient-to-b from-amber-50/60 to-[#fdfaf4]">
        <div className="mx-auto flex max-w-4xl flex-col items-center px-6 py-16 text-center">
          <Image
            src={author.avatarUrl}
            alt={author.name}
            width={112}
            height={112}
            className="h-28 w-28 rounded-full border-4 border-white bg-amber-50 shadow-md"
          />
          <h1 className="mt-5 font-serif text-3xl font-bold text-stone-950">{author.name}</h1>
          <p className="mt-1 text-sm font-semibold text-amber-700">{author.role}</p>
          <p className="mx-auto mt-4 max-w-2xl text-stone-600">{author.bio}</p>
          {author.twitter && (
            <p className="mt-3 text-sm text-stone-500">{author.twitter}</p>
          )}
          <p className="mt-4 text-sm font-semibold text-stone-500">
            {posts.length} published article{posts.length === 1 ? "" : "s"}
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-14">
        {posts.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-stone-300 p-12 text-center text-stone-500">
            This author hasn&apos;t published any articles yet.
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
