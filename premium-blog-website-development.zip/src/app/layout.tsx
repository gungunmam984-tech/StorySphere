import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Playfair_Display, Inter } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-serif",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Lumière Journal — A Premium Blog on Life, Work & Wellbeing",
    template: "%s | Lumière Journal",
  },
  description:
    "Lumière Journal is a premium blog covering technology, travel, lifestyle, finance and health — written to help you live and work with intention.",
  keywords: [
    "blog",
    "premium blog",
    "technology",
    "travel",
    "lifestyle",
    "finance",
    "health",
  ],
  openGraph: {
    title: "Lumière Journal — A Premium Blog on Life, Work & Wellbeing",
    description:
      "Thoughtful, in-depth articles on technology, travel, lifestyle, finance and health.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${playfair.variable} ${inter.variable}`}>
      <body className="flex min-h-screen flex-col bg-[#fdfaf4] font-sans text-stone-900 antialiased">
        <Navbar />
        <div className="flex-1">{children}</div>
        <Footer />
      </body>
    </html>
  );
}
