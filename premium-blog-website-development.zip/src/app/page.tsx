import Image from "next/image";
import Link from "next/link";
import PostCard from "@/components/PostCard";
import NewsletterForm from "@/components/NewsletterForm";
import { formatDate } from "@/lib/format";
import {
  getAllAuthors,
  getAllCategories,
  getAllPosts,
  getFeaturedPosts,
  getPopularPosts,
} from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [featured, allPosts, categories, popular, authors] = await Promise.all([
    getFeaturedPosts(3),
    getAllPosts(),
    getAllCategories(),
    getPopularPosts(4),
    getAllAuthors(),
  ]);

  const heroPost = featured[0] ?? allPosts[0];
  const latestPosts = allPosts.filter((p) => p.id !== heroPost?.id).slice(0, 6);

  return (
    <main>
      {/* Hero */}
      <section className="border-b border-amber-100 bg-gradient-to-b from-amber-50/60 to-[#fdfaf4]">
        <div className="mx-auto grid max-w-7xl gap-12 px-6 py-16 lg:grid-cols-2 lg:items-center lg:py-24">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-amber-100 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-amber-800">
              ✦ A premium journal for curious minds
            </span>
            <h1 className="mt-6 font-serif text-4xl font-bold leading-[1.1] text-stone-950 sm:text-5xl lg:text-6xl">
              Stories & ideas worth <span className="text-amber-600">slowing down</span> for.
            </h1>
            <p className="mt-6 max-w-lg text-lg leading-relaxed text-stone-600">
              Lumière Journal is a home for in-depth, honest writing on technology, travel,
              lifestyle, finance and health — made for readers who want more than headlines.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link
                href="/blog"
                className="rounded-full bg-stone-900 px-7 py-3.5 text-sm font-semibold text-white transition hover:bg-amber-700"
              >
                Explore all articles
              </Link>
              <Link
                href="/about"
                className="rounded-full border border-stone-300 px-7 py-3.5 text-sm font-semibold text-stone-800 transition hover:border-amber-400 hover:text-amber-700"
              >
                Meet the writers
              </Link>
            </div>
            <div className="mt-10 flex items-center gap-6 text-sm text-stone-500">
              <div>
                <p className="font-serif text-2xl font-bold text-stone-900">{allPosts.length}+</p>
                <p>Published articles</p>
              </div>
              <div className="h-8 w-px bg-stone-300" />
              <div>
                <p className="font-serif text-2xl font-bold text-stone-900">{categories.length}</p>
                <p>Focus categories</p>
              </div>
              <div className="h-8 w-px bg-stone-300" />
              <div>
                <p className="font-serif text-2xl font-bold text-stone-900">{authors.length}</p>
                <p>Expert writers</p>
              </div>
            </div>
          </div>

          {heroPost && (
            <Link href={`/blog/${heroPost.slug}`} className="group block">
              <div className="relative aspect-[4/5] w-full overflow-hidden rounded-3xl shadow-2xl">
                <Image
                  src={heroPost.coverImage}
                  alt={heroPost.title}
                  fill
                  priority
                  className="object-cover transition duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-7 text-white">
                  <span className="rounded-full bg-amber-500/90 px-3 py-1 text-xs font-semibold">
                    {heroPost.category.icon} {heroPost.category.name}
                  </span>
                  <h2 className="mt-3 font-serif text-2xl font-semibold leading-snug">
                    {heroPost.title}
                  </h2>
                  <p className="mt-2 text-sm text-white/80">
                    {heroPost.author.name} · {formatDate(heroPost.publishedAt)}
                  </p>
                </div>
              </div>
            </Link>
          )}
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="flex items-end justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-wider text-amber-700">Browse by topic</p>
            <h2 className="mt-2 font-serif text-3xl font-bold text-stone-950">Find your next favorite read</h2>
          </div>
        </div>
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {categories.map((category) => (
            <Link
              key={category.id}
              href={`/category/${category.slug}`}
              className="group flex flex-col items-center gap-3 rounded-2xl border border-stone-100 bg-white p-6 text-center transition hover:-translate-y-1 hover:border-amber-200 hover:shadow-lg"
            >
              <span className="text-3xl">{category.icon}</span>
              <span className="font-serif text-base font-semibold text-stone-900 group-hover:text-amber-700">
                {category.name}
              </span>
              <span className="line-clamp-2 text-xs text-stone-500">{category.description}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured */}
      {featured.length > 1 && (
        <section className="bg-white py-16">
          <div className="mx-auto max-w-7xl px-6">
            <div className="flex items-end justify-between">
              <div>
                <p className="text-sm font-semibold uppercase tracking-wider text-amber-700">Editor&apos;s picks</p>
                <h2 className="mt-2 font-serif text-3xl font-bold text-stone-950">Featured articles</h2>
              </div>
              <Link href="/blog" className="hidden text-sm font-semibold text-amber-700 hover:underline sm:block">
                View all articles →
              </Link>
            </div>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {featured.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Latest + Sidebar */}
      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-12 lg:grid-cols-[2fr_1fr]">
          <div>
            <div className="flex items-end justify-between">
              <h2 className="font-serif text-3xl font-bold text-stone-950">Latest articles</h2>
              <Link href="/blog" className="text-sm font-semibold text-amber-700 hover:underline">
                View all →
              </Link>
            </div>
            <div className="mt-8 flex flex-col gap-6">
              {latestPosts.map((post) => (
                <PostCard key={post.id} post={post} variant="horizontal" />
              ))}
            </div>
          </div>

          <aside className="flex flex-col gap-10">
            <div className="rounded-2xl border border-stone-100 bg-white p-6">
              <h3 className="font-serif text-lg font-semibold text-stone-900">Most popular</h3>
              <div className="mt-5 flex flex-col gap-5">
                {popular.map((post) => (
                  <PostCard key={post.id} post={post} variant="compact" />
                ))}
              </div>
            </div>

            <div className="rounded-2xl border border-stone-100 bg-white p-6">
              <h3 className="font-serif text-lg font-semibold text-stone-900">Our writers</h3>
              <div className="mt-5 flex flex-col gap-4">
                {authors.map((author) => (
                  <Link key={author.id} href={`/author/${author.slug}`} className="group flex items-center gap-3">
                    <Image
                      src={author.avatarUrl}
                      alt={author.name}
                      width={44}
                      height={44}
                      className="h-11 w-11 rounded-full border border-stone-200 bg-amber-50"
                    />
                    <div>
                      <p className="text-sm font-semibold text-stone-800 group-hover:text-amber-700">{author.name}</p>
                      <p className="text-xs text-stone-500">{author.role}</p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-stone-900 p-6 text-white">
              <h3 className="font-serif text-lg font-semibold">Never miss an issue</h3>
              <p className="mt-2 text-sm text-stone-300">
                Get our best articles delivered to your inbox every week.
              </p>
              <div className="mt-4">
                <NewsletterForm variant="dark" />
              </div>
            </div>
          </aside>
        </div>
      </section>
    </main>
  );
}
