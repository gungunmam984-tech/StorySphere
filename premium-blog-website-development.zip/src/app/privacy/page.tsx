import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "Read the Lumière Journal privacy policy to understand how we collect and use your data.",
};

export default function PrivacyPage() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-16">
      <p className="text-sm font-semibold uppercase tracking-wider text-amber-700">Legal</p>
      <h1 className="mt-2 font-serif text-4xl font-bold text-stone-950">Privacy Policy</h1>
      <p className="mt-3 text-sm text-stone-500">Last updated: January 2026</p>

      <div className="prose-article mt-10">
        <h2>1. Information we collect</h2>
        <p>
          When you subscribe to our newsletter, leave a comment, or contact us through this site,
          we collect the information you provide directly, such as your name and email address.
          We also collect basic analytics data (such as pages visited) to help us understand how
          our content is used.
        </p>

        <h2>2. How we use your information</h2>
        <ul>
          <li>To deliver newsletter emails you've subscribed to.</li>
          <li>To display comments you've submitted on articles.</li>
          <li>To respond to messages sent through our contact form.</li>
          <li>To improve our content based on aggregate reading patterns.</li>
        </ul>

        <h2>3. Data sharing</h2>
        <p>
          We do not sell your personal information to third parties. We may use trusted service
          providers (such as email delivery or hosting providers) solely to operate this website.
        </p>

        <h2>4. Cookies</h2>
        <p>
          We use minimal cookies necessary for the site to function properly. We do not use
          third-party advertising trackers.
        </p>

        <h2>5. Your rights</h2>
        <p>
          You can request access to, correction of, or deletion of your personal data at any time
          by contacting us at hello@lumierejournal.com. You may unsubscribe from our newsletter
          using the link in any email we send.
        </p>

        <h2>6. Changes to this policy</h2>
        <p>
          We may update this privacy policy from time to time. Any changes will be posted on this
          page with an updated revision date.
        </p>

        <h2>7. Contact us</h2>
        <p>
          If you have any questions about this privacy policy, please reach out through our{" "}
          <a href="/contact" className="font-semibold text-amber-700 underline">contact page</a>.
        </p>
      </div>
    </main>
  );
}
