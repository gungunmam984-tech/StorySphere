import type { Metadata } from "next";
import ContactForm from "@/components/ContactForm";

export const metadata: Metadata = {
  title: "Contact Us",
  description: "Get in touch with the Lumière Journal team for pitches, feedback or partnership inquiries.",
};

const faqs = [
  {
    q: "Can I pitch a guest article?",
    a: "Yes! Send us a short outline and a sample of your previous writing through the form below and our editors will respond within a week.",
  },
  {
    q: "Do you offer advertising or sponsorships?",
    a: "We work with a limited number of brands each quarter that align with our editorial values. Reach out with details about your product or service.",
  },
  {
    q: "How do I report an error in an article?",
    a: "We take accuracy seriously. Send us the article title and a link, and we'll review and correct it promptly.",
  },
];

export default function ContactPage() {
  return (
    <main>
      <section className="border-b border-amber-100 bg-gradient-to-b from-amber-50/60 to-[#fdfaf4]">
        <div className="mx-auto max-w-3xl px-6 py-16 text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-amber-700">Get in touch</p>
          <h1 className="mt-3 font-serif text-4xl font-bold text-stone-950 sm:text-5xl">We'd love to hear from you</h1>
          <p className="mx-auto mt-4 max-w-xl text-stone-600">
            Whether it's a story idea, feedback on an article, or a partnership inquiry — our team
            reads every message personally.
          </p>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-12 px-6 py-16 lg:grid-cols-[1.2fr_1fr]">
        <div className="rounded-3xl border border-stone-100 bg-white p-8">
          <h2 className="font-serif text-2xl font-bold text-stone-950">Send us a message</h2>
          <div className="mt-6">
            <ContactForm />
          </div>
        </div>

        <div className="flex flex-col gap-8">
          <div className="rounded-3xl border border-stone-100 bg-white p-8">
            <h3 className="font-serif text-lg font-semibold text-stone-900">Contact details</h3>
            <ul className="mt-4 space-y-3 text-sm text-stone-600">
              <li>📧 hello@lumierejournal.com</li>
              <li>📍 Remote-first — writers around the world</li>
              <li>⏱ We respond within 1-2 business days</li>
            </ul>
          </div>

          <div className="rounded-3xl border border-stone-100 bg-white p-8">
            <h3 className="font-serif text-lg font-semibold text-stone-900">Frequently asked</h3>
            <div className="mt-4 flex flex-col gap-4">
              {faqs.map((faq) => (
                <div key={faq.q}>
                  <p className="text-sm font-semibold text-stone-900">{faq.q}</p>
                  <p className="mt-1 text-sm text-stone-600">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
